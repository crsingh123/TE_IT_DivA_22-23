# Garbage Detection

This is a simple project to detect garbage using transformers and huggingface.

## Installation

```bash
pip install -r requirements.txt
```

## Usage

```bash
streamlit run main.py
```

## Contributing

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.
