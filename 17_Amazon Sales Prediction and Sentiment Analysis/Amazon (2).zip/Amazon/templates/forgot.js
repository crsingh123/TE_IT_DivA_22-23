function change(){
    alert("Hello");
    var change_uname = $("#change_uname").val();
    var change_email = $("#change_email").val();
    var change_pass = $("#change_pass").val();
    var change_cpass = $("#change_cpass").val();
    var paswd=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
    if(change_uname == "" || change_email == "" || change_pass == "" || change_cpass ==""){
        alert("Enter all the fields to register.");
    }
    else if(!change_pass.match(paswd)){
        alert("Length of password must be between 8 to 20 along with atleast one numerical and special character present.");
    }
    else if(change_pass != change_cpass){
        alert("Sorry password didn't match, Check again!");
    }
    else{
        $.post("forgot.php",{change_uname:change_uname,change_email:change_email,change_pass:change_pass},
        function(data){
            $('#result').html(data);
            window.location.href = "http://localhost/Amazon%20Sales%20Prediction%20and%20Sentiment%20Analysis/templates/login1.html"; 
        });
    }
}