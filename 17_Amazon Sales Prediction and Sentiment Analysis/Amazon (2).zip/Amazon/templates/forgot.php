<?php
$change_uname = $_POST['change_uname'];
$change_email = $_POST['change_email'];
$change_pass = $_POST['change_pass'];
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','amazon_vendors');
$change_query = "SELECT * FROM `register` WHERE uname='$change_uname' and email='$change_email'";
$res_change = mysqli_query($con,$change_query);
if($res_change->num_rows == 1)
{
    $query = "UPDATE `register` SET `pass`=md5('($change_pass)') WHERE `email`='$change_email'";
    $rs = mysqli_query($con,$query);
    if($rs){
        echo '<script>alert("Your password is changed successfully. You can login now");</script>';
    }
    else{
        echo '<script>alert("Your password cannot be changed..please try again!!");</script>';
    }
    // echo '<script>alert("Your password is changed successfully. You can login now");</script>'; 
}
else{
    echo '<script>alert("Your account is not yet registered.Please register first!");</script>';
}
$con->close(); 
?>