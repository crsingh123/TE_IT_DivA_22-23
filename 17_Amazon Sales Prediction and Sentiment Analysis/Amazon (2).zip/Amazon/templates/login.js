var x = document.getElementById("login");
var y = document.getElementById("register");
var z = document.getElementById("btn");

function register(){
    x.style.left = "-400px";
    y.style.left = "50px";
    z.style.left = "110px";
}
function login(){
    x.style.left = "50px";
    y.style.left = "450px";
    z.style.left = "0px";
}
function registerSubmit(){
    var uname = $("#uname").val();
    var email = $("#email").val();
    var pass = $("#pass").val();
    var paswd=  /^(?=.*[0-9])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*]{8,20}$/;
    if(email =="" || email == "" || pass == ""){
        alert("Enter all the fields to register.")
    }
    else if(!pass.match(paswd)){
        alert("Length of password must be between 8 to 20 along with atleast one numerical and special character present.");
    }
    else{
        $.post("login.php",{uname:uname,email:email,pass:pass},
        function(data){
            alert(data);
            $('#result').html(data);
            $('#register')[0].reset();
        });
    } 
}
function loginSubmit(){
    var log_uname = $("#log_uname").val();
    var log_pass = $("#log_pass").val();
    if(log_uname =="" || log_pass==""){
        alert("Enter all the fields to login.");
    }
    else{
        $.post("login.php",{log_uname:log_uname,log_pass:log_pass},
        function(data){
            alert(data);
            $('#log_result').html(data);
            $('#login')[0].reset();
        })
    }
}