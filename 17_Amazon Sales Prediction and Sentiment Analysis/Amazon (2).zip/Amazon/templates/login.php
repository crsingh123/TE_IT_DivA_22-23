<?php 
$con = mysqli_connect('localhost', 'root', 'Ashmina27@','amazon_vendors');
if(isset($_POST['uname'],$_POST['email'],$_POST['pass'])){
    $uname = $_POST['uname'];
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    $query = "INSERT INTO `register`(`uname`, `email`, `pass`) VALUES ('$uname','$email',md5('($pass)'))";
    $rs = mysqli_query($con, $query);
    if($rs)
    {
        echo 'You are now successfully registered. You may login now!'; 
    }
    else{
        echo 'Please try again to reach us.';
    }
}
if(isset($_POST['log_uname'],$_POST['log_pass'])){
    session_start();
    $log_uname = $_POST['log_uname'];
    $log_pass = $_POST['log_pass'];
    $log_query = "SELECT `uname`, `pass` FROM `register` WHERE uname='$log_uname' and pass=md5('($log_pass)')";
    $res_log = mysqli_query($con,$log_query);
    if($res_log->num_rows > 0){
        echo '<script>alert("You have successfully logged in");</script>';
        // while($row = $res_log->fetch_assoc()){
        //     $username = $row['uname'];
        //     header("Location:http://localhost/try/page1.html");

            
        // }
    }
    else{
        echo 'Invalid credentials,please try again!';
    }
}
$con->close(); 
?>
