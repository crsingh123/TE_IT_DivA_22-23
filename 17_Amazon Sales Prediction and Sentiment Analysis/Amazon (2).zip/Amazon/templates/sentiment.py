from flask import *
import pandas as pd
import numpy as np
import pickle
import json
import plotly
import plotly.express as px
import joblib
import os
import numpy as np

app = Flask(__name__)

@app.route("/")
def index():
    return render_template("home.html")

@app.route('/predict',methods=['POST','GET'])
def result():
    item_weight= float(request.form['item_weight'])
    item_fat_content=float(request.form['item_fat_content'])
    item_visibility= float(request.form['item_visibility'])
    item_type= float(request.form['item_type'])
    item_mrp = float(request.form['item_mrp'])
    outlet_establishment_year= float(request.form['outlet_establishment_year'])
    outlet_size= float(request.form['outlet_size'])
    outlet_location_type= float(request.form['outlet_location_type'])
    outlet_type= float(request.form['outlet_type'])

    X= np.array([[ item_weight,item_fat_content,item_visibility,item_type,item_mrp,
                  outlet_establishment_year,outlet_size,outlet_location_type,outlet_type ]])

    scaler_path= r'C:\xampp\htdocs\Amazon Sales Prediction and Sentiment Analysis\models\sc.sav'

    sc=joblib.load(scaler_path)

    X_std= sc.transform(X)

    model_path=r'C:\xampp\htdocs\Amazon Sales Prediction and Sentiment Analysis\models\lr.sav'

    model= joblib.load(model_path)

    # Y_pred=model.predict(X_std)
    try:
            # result=model.predict([feature])[0]
            Y_pred=model.predict(X_std)
            print(Y_pred)
            return render_template("home.html",output=Y_pred)
    except:
            print("Error")

    # return jsonify({'Prediction': float(Y_pred)})
    return render_template("home.html")
my_value = ""
model = pd.read_pickle(open(r'C:\xampp\htdocs\Amazon Sales Prediction and Sentiment Analysis\src\sentiment.pkl','rb'))

@app.route('/paneer/sentiment')
def sentiment(): 
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Amul Fresh Paneer"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/tadka_chash/sentiment')
def dairy_chash():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Mother Dairy Tadka Chas"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/cheese/sentiment')
def dairy_cheese():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Mother Dairy Cheese"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/butter/sentiment')
def dairy_butter():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Amul lite spread"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/sandwich_bread/sentiment')
def sandwich_bread():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Sandwich bread"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/whole_wheat_bread/sentiment')
def whole_wheat_bread():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Whole wheat bread"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/ragi_loaf/sentiment')
def ragi_loaf():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Ragi Loaf"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

@app.route('/garlic_bread/sentiment')
def garlic_bread():
    df = pd.DataFrame(model)
    df_amul = df.loc[df['product_name'] == "Garlic bread"]
    df2 = df_amul.pivot_table(columns=['sentiment'], aggfunc='size')
    df3 = df_amul.pivot_table(columns=['Star-rating'], aggfunc='size')
    fig = px.bar(df2,barmode='group',color="value")
    figg = px.bar(df3,barmode='group',color="value")
    positive_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Positive', 'Review Content'])
    negative_reviews = list(df_amul.loc[df_amul['sentiment'] == 'Negative', 'Review Content'])
    graphJSON = json.dumps(fig, cls=plotly.utils.PlotlyJSONEncoder)
    graphJSONs = json.dumps(figg, cls=plotly.utils.PlotlyJSONEncoder)
    return render_template('sentiment_analysis.html', graphJSON=graphJSON,graphJSONs=graphJSONs,positive_reviews=positive_reviews,negative_reviews=negative_reviews)

if __name__ == "__main__":
    app.run(debug=True, port=9457)