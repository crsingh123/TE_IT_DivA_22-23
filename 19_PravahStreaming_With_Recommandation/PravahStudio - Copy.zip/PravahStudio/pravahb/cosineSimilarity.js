function dotProduct(a, b) {
    let result = 0;
    for (let i = 0; i < a.length; i++) {
        result += a[i] * b[i];
    }
    return result;
}

function magnitude(a) {
    let result = 0;
    for (let i = 0; i < a.length; i++) {
        result += a[i] * a[i];
    }
    return Math.sqrt(result);
}

function cosineSimilarity(a, b) {
    const similarity = [];
    const magnitudeA = magnitude(a);
    const magnitudeB = magnitude(b);
    for (let i = 0; i < b.length; i++) {
        const dot = dotProduct(a, b[i]);
        const magnitudeI = magnitude(b[i]);
        const cos = dot / (magnitudeA * magnitudeI);
        similarity.push([i, cos]);
    }
    similarity.sort((a, b) => b[1] - a[1]);
    return similarity;
}

module.exports = { cosineSimilarity };
