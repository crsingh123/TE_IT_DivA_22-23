const express = require('express');
const nodemailer = require('nodemailer');
const bcrypt = require('bcrypt');
const { v4: uuidv4 } = require('uuid');
const { MongoClient } = require('mongodb');
const cors = require('cors'); // Add this line


const bodyParser = require('body-parser');
const natural = require('natural');
const TfIdf = natural.TfIdf;





const app = express();
app.use(cors()); // Add this line before any routes

// Parse JSON request body
app.use(express.json());

// Connect to MongoDB
const uri = 'mongodb://localhost:27017';
const client = new MongoClient(uri, { useNewUrlParser: true, useUnifiedTopology: true });
client.connect();



app.post('/musicd', async (req, res) => {
  // Extract the music data from the request body
  const musicDataArray = req.body;

  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MusicData" collection
    const collection = client.db("MediaData").collection("MusicData");

    // Insert the music data into the collection
    const result = await collection.insertMany(musicDataArray);

    // Close the database connection
    client.close();

    // Send a response to the client
    res.send(`${musicDataArray.length} songs have been added to the database.`);
  } catch (error) {
    console.error(error);
    res.status(500).send("Internal server error.");
  }
});






// Define route for handling POST requests
app.post('/movies', (req, res) => {
  // Extract the movie data from the request body
  const movieData = req.body;

  // Connect to MongoDB
  MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) throw err;

    // Get the "MovieData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Insert the movie data into the collection
    collection.insertOne(movieData, (err, result) => {
      if (err) throw err;

      // Close the database connection
      client.close();

      // Send a response to the client
      res.send(`Movie with ID ${movieData.Movie_ID} has been added to the database.`);
    });
  });
});



app.post('/api/register', async (req, res) => {
  try {
    // Check if required fields are present
    if (!req.body.username || !req.body.dob || !req.body.email || !req.body.contact || !req.body.password) {
      return res.status(400).json({ message: 'Required fields are missing' });
    }

    // Extract user data from request body
    const { username, dob, email, contact, password } = req.body;

    // Hash the password
    const hashedPassword = await bcrypt.hash(password, 10);

    // Generate activation token
    const token = uuidv4();

    // Save user data to MongoDB
    const db = client.db('myapp');
    const collection = db.collection('users');
    const result = await collection.insertOne({
      username,
      dob,
      email,
      contact,
      password: hashedPassword,
      active: false,
      token
    });
    console.log(result);

    // Send activation email
    const transporter = nodemailer.createTransport({
      host: 'smtp.gmail.com',
      port: 587,
      secure: false,
      auth: {
        user: 'vishnukantmule@gmail.com',
        pass: 'uptrlfhdqcuejikv'
      }
    });
    const mailOptions = {
      from: 'vishnukantmule@gmail.com',
      to: email,
      subject: 'Activate Your Account',
      text: `Hello ${username},\n\nPlease click the following link to activate your account:\n\nhttp://localhost:4000/api/activate/${token}\n\nBest regards,\nMyApp Team`
    };
    await transporter.sendMail(mailOptions);

    // Send response to client
    res.status(200).json({ message: 'Registration successful' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
});



// Handle account activation
app.get('/api/activate/:token', async (req, res) => {
  try {
    // Find user by activation token
    const { token } = req.params;
    const db = client.db('myapp');
    const collection = db.collection('users');
    const user = await collection.findOne({ token });

    if (!user) {
      return res.status(400).json({ message: 'Invalid activation token' });
    }

    // Activate user account
    await collection.updateOne({ _id: user._id }, { $set: { active: true } });

    // Send response to client
    res.status(200).json({ message: 'Account activated' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
});



// Handle login
app.post('/api/login', async (req, res) => {
  try {
    // Check if required fields are present
    if (!req.body.email || !req.body.password) {
      return res.status(400).json({ message: 'Required fields are missing' });
    }

    // Extract user data from request body
    const { email, password } = req.body;

    // Find user by email
    const db = client.db('myapp');
    const collection = db.collection('users');
    const user = await collection.findOne({ email });

    if (!user) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if password is correct
    const passwordMatch = await bcrypt.compare(password, user.password);

    if (!passwordMatch) {
      return res.status(401).json({ message: 'Invalid email or password' });
    }

    // Check if account is activated
    if (!user.active) {
      return res.status(401).json({ message: 'Account is not activated' });
    }

    // Send response to client
    res.status(200).json({ message: 'Login successful', username: user.username });
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Internal server error' });
  }
});




// Define endpoint to get all the music data
app.get('/music', async (req, res) => {
  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
  
    // Get the "MusicData" collection
    const collection = client.db("MediaData").collection("MusicData");

    // Find all the music data in the collection
    const musicData = await collection.find().toArray();

    // Close the database connection
    client.close();

    // Return the music data as a JSON response
    res.json(musicData);
  } catch (err) {
    console.error(err);
    res.status(500).send('Internal Server Error');
  }
});


// Define endpoint to get the data for a single music track based on its ID
app.get('/music/:id', async (req, res) => {
  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    
    // Get the "MusicData" collection
    const collection = client.db("MediaData").collection("MusicData");

    // Find the music track with the requested ID in the collection
    const selectedMusic = await collection.findOne({ Music_ID: req.params.id });

    // If the music track is not found, return a 404 error response
    if (!selectedMusic) {
      return res.status(404).json({ error: 'Music not found' });
    }

    // Close the database connection
    client.close();

    // Return the selected music track as a JSON response
    res.json(selectedMusic);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});




app.post('/recommend', async (req, res) => {
  try {
    // create TF-IDF instance and add documents
    const tfidf = new TfIdf();

    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Fetch all movies from the collection
    const movies = await collection.find().toArray();

    // Add each movie's text to the TF-IDF instance
    movies.forEach(movie => {
      const text = `${movie.Movie_Name} ${movie.Movie_Cast.join(' ')} ${movie.Movie_Genre.join(' ')} ${movie.Movie_Comment.map(comment => comment.Comment).join(' ')}`;
      tfidf.addDocument(text);
    });

    const { movie_id } = req.body;

    // find the selected movie
    const selectedMovie = movies.find(movie => movie.Movie_ID === movie_id);

    if (!selectedMovie) {
      return res.status(404).json({ message: 'Movie not found' });
    }

    // calculate similarity scores with all other movies
    const similarityScores = [];
    const selectedText = `${selectedMovie.Movie_Name} ${selectedMovie.Movie_Cast.join(' ')} ${selectedMovie.Movie_Genre.join(' ')} ${selectedMovie.Movie_Comment.map(comment => comment.Comment).join(' ')}`;
    tfidf.tfidfs(selectedText, (index, score) => {
      similarityScores.push({
        Movie_ID: movies[index].Movie_ID,
        Score: score
      });
    });

    // sort the similarity scores in descending order
    const sortedScores = similarityScores.sort((a, b) => b.Score - a.Score);

    // exclude the selected movie and select top 5 similar movies
    const recommendedMovies = sortedScores
      .filter(score => score.Movie_ID !== movie_id)
      .slice(0, 20)
      .map(score => movies.find(movie => movie.Movie_ID === score.Movie_ID));

    res.json(recommendedMovies);
  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server Error' });
  }
});





app.get('/marathi_movies', async (req, res) => {
  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Find movies where Movie_Language is "Marathi"
    const movies = await collection.find({ Movie_Language: "Marathi" }).toArray();

    // Close the database connection
    client.close();

    // Send the filtered movies to the client
    res.json(movies);
  } catch (err) {
    console.log(err);
    res.status(500).send("Error connecting to database");
  }
});



app.get('/hindi_movies', async (req, res) => {
  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Find movies where Movie_Language is "Marathi"
    const movies = await collection.find({ Movie_Language: "Hindi" }).toArray();

    // Close the database connection
    client.close();

    // Send the filtered movies to the client
    res.json(movies);
  } catch (err) {
    console.log(err);
    res.status(500).send("Error connecting to database");
  }

});

app.get('/english_movies', async (req, res) => {
  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Find movies where Movie_Language is "Marathi"
    const movies = await collection.find({ Movie_Language: "English" }).toArray();

    // Close the database connection
    client.close();

    // Send the filtered movies to the client
    res.json(movies);
  } catch (err) {
    console.log(err);
    res.status(500).send("Error connecting to database");
  }
});



app.post('/comment', async (req, res) => {
  const { movie_id, username, comment } = req.body;

  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true }).catch(err => {
      console.error(err);
      res.status(500).json({ message: 'Failed to connect to database' });
    });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Find the movie in the collection by ID
    const movie = await collection.findOne({ Movie_ID: movie_id });

    if (!movie) {
      // Movie not found
      client.close();
      return res.status(404).json({ message: 'Movie not found' });
    }

    // Add the new comment to the movie's comments array
    const newComment = { Username: username, Comment: comment };
    movie.Movie_Comment.push(newComment);

    // Update the movie in the database with the new comment
    const result = await collection.updateOne({ Movie_ID: movie_id }, { $set: { Movie_Comment: movie.Movie_Comment } });

    // Close the database connection
    client.close();

    // Send a response to the client
    res.json({ message: 'Comment added successfully' });
  } catch (err) {
    // Handle any errors that occurred during the process
    console.error(err);
    res.status(500).json({ message: 'An error occurred' });
  }
});


app.post('/like', (req, res) => {
  const { movie_id } = req.body;

  // Connect to MongoDB
  MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
    if (err) {
      console.error(err);
      return res.status(500).json({ message: 'Internal server error' });
    }

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Update the "Movie_Like" count for the specified movie
    collection.updateOne(
      { Movie_ID: movie_id },
      { $inc: { Movie_Like: 1 } },
      (err, result) => {
        if (err) {
          console.error(err);
          return res.status(500).json({ message: 'Internal server error' });
        }

        // Check if the movie was found and updated
        if (result.matchedCount === 0) {
          return res.status(404).json({ message: 'Movie not found' });
        } else if (result.modifiedCount === 0) {
          return res.status(500).json({ message: 'Movie like count not updated' });
        }

        // Close the database connection
        client.close();

        // Send a response to the client
        res.json({ message: 'Movie like count updated' });
      }
    );
  });
});


app.post('/history', async (req, res) => {
  const { username, movie_id } = req.body;

  // Find the user in the database
  const db = client.db('myapp');
  const collection = db.collection('users');
  const user = await collection.findOne({ username });

  // Check if the user exists
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }

  // If the user doesn't have a history field yet, create it
  if (!user.History) {
    await collection.updateOne({ username }, { $set: { History: [movie_id] } });
  } else {
    // If the user already has a history field, add the new movie_id to it
    await collection.updateOne({ username }, { $addToSet: { History: movie_id } });
  }
  const moviesCollection = client.db("MediaData").collection("MoviesData");

  // Update the movie views count
  const movie = await moviesCollection.findOne({ Movie_ID: movie_id });
  if (movie) {
    const newViewsCount = movie.Movie_Views + 1;
    try {
      await moviesCollection.updateOne({ Movie_ID: movie_id }, { $set: { Movie_Views: newViewsCount } });
    } catch (error) {
      console.log(error);
    }
  } else {
    console.log(`Movie with ID ${movie_id} not found.`);
  }

  res.json({ message: 'Movie added to user history' });
});




app.post('/save', async (req, res) => {
  const { username, movie_id } = req.body;

  // Find the user in the database
  const db = client.db('myapp');
  const collection = db.collection('users');
  const user = await collection.findOne({ username });

  // Check if the user exists
  if (!user) {
    return res.status(404).json({ message: 'User not found' });
  }

  // If the user doesn't have a history field yet, create it
  if (!user.History) {
    await collection.updateOne({ username }, { $set: { Saved: [movie_id] } });
  } else {
    // If the user already has a history field, add the new movie_id to it
    await collection.updateOne({ username }, { $addToSet: { Saved: movie_id } });
  }

  res.json({ message: 'Movie added to user history' });
});


app.post('/userh', async (req, res) => {
  const { username } = req.body;


  try {
    // Find the user's data based on the username
    const usersCollection = client.db('myapp').collection('users');
    const user = await usersCollection.findOne({ username });

    if (!user) {
      // If the user is not found, return an error message
      return res.status(404).send({ message: 'User not found' });
    }

    // Retrieve the user's movie history from the "History" field
    const movieIds = user.History;

    // Find the movies based on the movieIds
    const moviesCollection = client.db('MediaData').collection('MoviesData');
    const movies = await moviesCollection.find({ Movie_ID: { $in: movieIds } }).toArray();

    // Return the movie details to the user
    return res.send({ movies });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'Internal server error' });
  }
});


app.post('/usersaved', async (req, res) => {
  const { username } = req.body;


  try {
    // Find the user's data based on the username
    const usersCollection = client.db('myapp').collection('users');
    const user = await usersCollection.findOne({ username });

    if (!user) {
      // If the user is not found, return an error message
      return res.status(404).send({ message: 'User not found' });
    }

    // Retrieve the user's movie history from the "History" field
    const movieIds = user.Saved;

    // Find the movies based on the movieIds
    const moviesCollection = client.db('MediaData').collection('MoviesData');
    const movies = await moviesCollection.find({ Movie_ID: { $in: movieIds } }).toArray();

    // Return the movie details to the user
    return res.send({ movies });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'Internal server error' });
  }
});



// Define endpoint to get the data for a single movie based on its ID
app.post('/play', async (req, res) => {
  const { id } = req.body;

  try {
    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "MoviesData" collection
    const collection = client.db("MediaData").collection("MoviesData");

    // Find the movie with the requested ID in the collection
    const selectedMovie = await collection.findOne({ Movie_ID: id });

    // If the movie is not found, return a 404 error response
    if (!selectedMovie) {
      return res.status(404).json({ error: 'Movie not found' });
    }

    // Close the database connection
    client.close();

    // Return the selected movie as a JSON response
    res.json(selectedMovie);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
});


app.post('/userdetails', async (req, res) => {
  const { username } = req.body;

  try {
    const usersCollection = client.db('myapp').collection('users');
    const user = await usersCollection.findOne({ username });

    if (!user) {
      return res.status(404).send({ message: 'User not found' });
    }

    return res.send({ user });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'Internal server error' });
  }
});

app.get('/trending', async (req, res) => {
  try {
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });
    const db = client.db('MediaData');
    const collection = db.collection('MoviesData');

    // Find the top 10 movies sorted by views in descending order
    const movies = await collection.find().sort({ Movie_Views: -1 }).limit(10).toArray();
    res.json(movies);

    client.close();
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: 'Error connecting to database' });
  }
});

// Define endpoint to get data for user's movie genre watch history
app.post('/moviegenere', async (req, res) => {
  try {
    const {username} = req.body;

    // Connect to MongoDB
    const client = await MongoClient.connect(uri, { useNewUrlParser: true, useUnifiedTopology: true });

    // Get the "Users" collection
    const usersCollection = client.db("myapp").collection("users");

    // Find the user in the collection by username
    const user = await usersCollection.findOne({ username: username });

    if (!user) {
      // User not found
      client.close();
      return res.status(404).json({ message: 'User not found' });
    }

    // Get the user's movie history from the database
    const movieIds = user.History;

    // Get the "MoviesData" collection
    const moviesCollection = client.db("MediaData").collection("MoviesData");

    // Find all movies with IDs in the user's movie history
    const movies = await moviesCollection.find({ Movie_ID: { $in: movieIds } }).toArray();

    // Create an object to store the number of movies watched for each genre
    const genreCount = {};

    // Loop through each movie and update the genre count
    movies.forEach(movie => {
      movie.Movie_Genre.forEach(genre => {
        if (genre in genreCount) {
          genreCount[genre] += 1;
        } else {
          genreCount[genre] = 1;
        }
      });
    });

    // Close the database connection
    client.close();

    // Return the genre count object as a JSON response
    res.json(genreCount);

  } catch (err) {
    console.error(err);
    res.status(500).json({ message: 'Server error' });
  }
});




app.delete('/deletehistory', async (req, res) => {
  const { username, movieIds } = req.body;

  try {
    // Find the user's data based on the username
    const usersCollection = client.db('myapp').collection('users');
    const user = await usersCollection.findOne({ username });

    if (!user) {
      // If the user is not found, return an error message
      return res.status(404).send({ message: 'User not found' });
    }

    // Remove the specified movies from the user's history
    await usersCollection.updateOne(
      { username },
      { $pull: { History: { $in: movieIds } } }
    );

    // Return a success message
    return res.send({ message: 'Movies removed from history' });
  } catch (err) {
    console.error(err);
    return res.status(500).send({ message: 'Internal server error' });
  }
});




// Start server
app.listen(4000, () => {
  console.log('Server started on port 4000');
});











