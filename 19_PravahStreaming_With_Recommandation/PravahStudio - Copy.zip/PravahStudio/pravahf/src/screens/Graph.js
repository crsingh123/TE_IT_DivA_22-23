import React, { useState, useEffect } from 'react';
import '../css/Graph.css';

const Graph = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    const fetchData = async () => {
      const response = await fetch('http://localhost:4000/moviegenere', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username: 'vishnukantmule'
        })
      });
      const responseData = await response.json();
      const chartData = Object.keys(responseData).map((genre) => ({ genre, count: responseData[genre] }));
      setData(chartData);
    };
    fetchData();
  }, []);

  return (
    <div className="graph-container" style={{backgroundColor: "black"}}>
      {data.length === 0 ? (
        <p>Loading chart...</p>
      ) : (
        <svg viewBox="0 0 600 400">
          <line x1="50" y1="350" x2="550" y2="350" stroke="#ccc" strokeWidth="1" />
          <line x1="50" y1="350" x2="50" y2="50" stroke="#ccc" strokeWidth="1" />
          {data.map((item, index) => (
            <React.Fragment key={index}>
              <text x={70 + index * 70} y="365" className="axis-text-white">
                {item.genre}
              </text>
              <rect
                x={60 + index * 70}
                y={350 - item.count * 20}
                width="50"
                height={item.count * 20}
                fill="#ADD8E6"
              />
              <text x={70 + index * 70} y={350 - item.count * 20 - 5} className="count-text-white">
                {item.count}
              </text>
            </React.Fragment>
          ))}
        </svg>
      )}
    </div>
  );
};

export default Graph;
