import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';

export default function History(props) {
  const [movies, setMovies] = useState([]);
  const [selectedMovies, setSelectedMovies] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const fetchMovies = async () => {
      try {
        const response = await fetch('http://localhost:4000/userh', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json'
          },
          body: JSON.stringify({ username: props.username })
        });
        const data = await response.json();
        setMovies(data.movies);
      } catch (error) {
        console.error(error);
      }
    };
    fetchMovies();
  }, [props.username]);

  const handleMovieClick = (movieId) => {
    navigate(`/play/${movieId}`);
  };

  const handleSelectChange = (e, movieId) => {
    if (e.target.checked) {
      setSelectedMovies([...selectedMovies, movieId]);
    } else {
      setSelectedMovies(selectedMovies.filter((id) => id !== movieId));
    }
  };

  const handleDeleteClick = async () => {
    try {
      const response = await fetch('http://localhost:4000/deletehistory', {
        method: 'DELETE',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          username: props.username,
          movieIds: selectedMovies
        })
      });
      const data = await response.json();
      console.log(data);
      // Remove the deleted movies from the state
      setMovies(movies.filter((movie) => !selectedMovies.includes(movie.Movie_ID)));
      setSelectedMovies([]);
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="movie-list">
      <div>
      <button className="delete-button" disabled={selectedMovies.length === 0} onClick={handleDeleteClick}>
  Delete selected
</button>      </div>
      {movies.map((movie) => (
        <div className="card" key={movie.Movie_ID}>
        <input
  type="checkbox"
  checked={selectedMovies.includes(movie.Movie_ID)}
  onChange={(e) => handleSelectChange(e, movie.Movie_ID)}
/>
          <img
            src={movie.Movie_Image}
            alt={movie.Movie_Name}
            onClick={() => handleMovieClick(movie.Movie_ID)}
          />
          <div className="card-content">
            <h2>{movie.Movie_Name}</h2>
            <p>{movie.Movie_Year}</p>
          </div>
        </div>
      ))}
    </div>
  );
}
