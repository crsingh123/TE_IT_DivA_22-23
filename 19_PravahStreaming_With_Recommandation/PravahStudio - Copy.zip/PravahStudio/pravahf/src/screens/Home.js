// import bgvideo from '../media/videos/bgvideo.mp4';

import Carousel from "../components/Carousel";
import Footer from "../components/Footer";
// import Section from "../components/Section";

import '../css/Footer.css'


export default function Home() {
  return (
    <>
    <Carousel className="footercss"/>
    <Footer/>
    </>
  );
}
 