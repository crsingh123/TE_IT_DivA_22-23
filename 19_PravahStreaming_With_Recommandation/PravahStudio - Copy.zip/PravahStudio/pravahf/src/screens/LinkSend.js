import React from 'react'
import '../css/LinkSend.css'

export default function LinkSend() {
  return (
    <div className="linksend-container">
    <h1>Activation Link Sent</h1>
    <p>Please check your email and click on the activation link to continue.</p>
  </div>
  )
}
