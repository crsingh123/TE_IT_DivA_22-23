import React from 'react'

export default function MainContent() {
  return (
    <div>MainContent</div>
  )
}
