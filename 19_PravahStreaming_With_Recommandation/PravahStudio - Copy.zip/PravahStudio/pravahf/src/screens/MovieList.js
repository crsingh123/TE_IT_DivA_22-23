import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/Recommanded.css';

function MovieList(props) {
  const navigate = useNavigate();
  const [showAllMovies, setShowAllMovies] = useState(false);

  const handleClick = (movieId) => {
    navigate(`/play/${movieId}`);
    fetch('http://localhost:4000/history', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        movie_id: movieId,
        username: props.username,
      })
    })
      .then(response => response.json())
      .catch(error => console.error(error));
  };

  const handleLoadMore = () => {
    setShowAllMovies(true);
  };

  const moviesToRender = showAllMovies ? props.movies : props.movies.slice(0, 10);

  return (
    <div className='movie-list-container'>
      <div className='movie-list'>
        {moviesToRender.map(movie => (
          <div className="card" key={movie.Movie_ID} onClick={() => handleClick(movie.Movie_ID)}>
            <img src={movie.Movie_Image} alt={movie.Movie_Name} />
            <div className="card-content">
              <h2>{movie.Movie_Name}</h2>
              <p>{movie.Movie_Year}</p>
            </div>
          </div>
        ))}
      </div>
      {!showAllMovies && props.movies.length > 10 && (
        <button className='load-more-button' onClick={handleLoadMore}>
          Load More
        </button>
      )}
    </div>
  );
}

export default MovieList;
