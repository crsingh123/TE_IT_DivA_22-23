import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import '../css/Recommanded.css'
import Loading from './Loading';
import MovieList from './MovieList';

function Recommanded(props) {
  const [marathiMovies, setMarathiMovies] = useState([]);
  const [englishMovies, setEnglishMovies] = useState([]);
  const [hindiMovies, setHindiMovies] = useState([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [showAllMovies, setShowAllMovies] = useState(false);
  const navigate = useNavigate();
  const numMoviesToShow = showAllMovies ? Infinity : 6; // Change 6 to the desired number of movies to display initially

  useEffect(() => {
    async function fetchMovies() {
      try {
        const marathiResponse = await fetch('http://localhost:4000/marathi_movies');
        const marathiData = await marathiResponse.json();
        setMarathiMovies(marathiData);

        const englishResponse = await fetch('http://localhost:4000/trending');
        const englishData = await englishResponse.json();
        setEnglishMovies(englishData);

        const hindiResponse = await fetch('http://localhost:4000/hindi_movies');
        const hindiData = await hindiResponse.json();
        setHindiMovies(hindiData);
      } catch (error) {
        console.error(error);
      }
    }
    fetchMovies();
  }, []);

  const handleClick = (movieId) => {
    navigate(`/play/${movieId}`);
    fetch('http://localhost:4000/userh', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        movie_id: movieId,
        username: props.username,
      })
    })
      .then(response => response.json())
      .catch(error => console.error(error));
  };

  const handleSearch = (event) => {
    setSearchQuery(event.target.value);
  };

  if (!marathiMovies || !englishMovies || !hindiMovies) {
    return <Loading />;
  }

  return (
    <div className='recommanded'>
      <br />
      <div className="search-container">
        <input type="text" placeholder="Search movies" value={searchQuery} onChange={handleSearch} />
      </div>
      <div className='head-language'>
        <hr />
        <h1>Marathi Movies</h1>
      </div>

      <div className="movie-list-container">
        <MovieList movies={marathiMovies.filter(movie => movie.Movie_Name.toLowerCase().includes(searchQuery.toLowerCase())).slice(0, numMoviesToShow)} handleClick={handleClick} />
      </div>



      {marathiMovies.length > numMoviesToShow && !showAllMovies && (
        <button className="load-more-button" onClick={() => setShowAllMovies(true)}>Load More</button>
      )}

      <div className='head-language'>
        <hr />
        <h1>Trending Movies</h1>
      </div>
      <MovieList movies={englishMovies.filter(movie => movie.Movie_Name.toLowerCase().includes(searchQuery.toLowerCase()))} handleClick={handleClick} />

      <div className='head-language'>
        <hr />
        <h1>Hindi Movies</h1>
      </div>
      <MovieList movies={hindiMovies.filter(movie => movie.Movie_Name.toLowerCase().includes(searchQuery.toLowerCase()))} handleClick={handleClick} />
    </div>
  );
}

export default Recommanded;
