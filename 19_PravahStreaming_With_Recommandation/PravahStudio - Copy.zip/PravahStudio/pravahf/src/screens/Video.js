import React from 'react'

export default function Video() {
  return (
    <div>Video</div>
  )
}
