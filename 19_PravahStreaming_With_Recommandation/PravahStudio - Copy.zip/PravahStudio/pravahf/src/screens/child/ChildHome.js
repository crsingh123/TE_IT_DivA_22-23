
import React, { useState, useEffect } from 'react';

function ChildHome() {
  const [movies, setMovies] = useState([]);
  const [selectedMovie, setSelectedMovie] = useState(null);

  useEffect(() => {
    async function fetchMovies() {
      const response = await fetch('http://localhost:4000/marathi_movies');
      const data = await response.json();
      setMovies(data);
    }
    fetchMovies();
  }, []);

  function handleClick(movie) {
    setSelectedMovie(movie);
  }

  function handleClose() {
    setSelectedMovie(null);
  }

  return (
    <div>
      {movies.map((movie) => (
        <div key={movie.Movie_ID} className="card" onClick={() => handleClick(movie)}>
          <img src={movie.Movie_Image} alt={movie.Movie_Name} />
          <div className="card-body">
            <h5 className="card-title">{movie.Movie_Name}</h5>
            <p className="card-text">{movie.Movie_Year}</p>
          </div>
        </div>
      ))}
      {selectedMovie && (
        <div className="modal">
          <div className="modal-content">
            <button className="close-btn" onClick={handleClose}>X</button>
            <iframe title="Movie Trailer" width="800" height="600" src={selectedMovie.Movie_Link} frameborder="0" allowfullscreen></iframe>
          </div>
        </div>
      )}
    </div>
  );
}

export default ChildHome;
